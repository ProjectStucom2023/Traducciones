package g_agenda;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/// EN ESTA CLASE LO QUE SE CONTROLA SON LAS PETICIONES UNA A UNA QUE TENGAN UN SINTAXIS CORRECTA.
/// FINALIZADO ESTE PROCESO TENDREMOS UN ARRAYLIST DE LAS CORRECTAS Y LAS INCORRECTAS.
/// EN OTRA PARTE DEL CODIGO EN EL MAIN O A PARTE HAY QUE REALIZAR LA PRIORIDADD DE LAS PETICIONES
/// PRIMERO LAS TANCAS  Y LUEGO LAS REUNIONJAVA.
/// TODAS LAS SALIDAS POR PANTALLA SE PODRAN ELIMINAR POSTERIORMENTE TODO QUE DA REFLEJADO DENTRO DE LOS
/// FICHERES incidencies.log y registro.log

public class LecturaPeticions {
	
	public static ArrayList<String> leerPeticiones(String fileRequest) {
		ArrayList<String> peticionesCorrectas = new ArrayList<>();
	    ArrayList<String> peticionesIncorrectas = new ArrayList<>();
	    String fileIncidents = "incidencies.log";
	    String fileLog = "registro.log";
	    try {
	        File file = new File(fileRequest);
	        Scanner scanner = new Scanner(file);
	        System.out.println("READING ALL REQUESTS");
	        System.out.println("___________________________________________________________");
	        while (scanner.hasNextLine()) {
	            String line = scanner.nextLine();
	            
	            System.out.println("Reading a request: " + line);
	            String[] components = line.split(" ");
	            /* Cada petición tiene 6 componentes */
	            if (components.length < 6) {
	                System.out.println("WARNING: Invalid request format" + line);
	                registrar(fileIncidents, "WARNING: Invalid request format - " + line);
	                continue; // Pasar a la siguiente línea
	            }
	            String activity = components[0];
	            String space = components[1];
	            String dateIN = components[2];
	            String dateOUT = components[3];
	            String daysAtWeek = components[4];
	            String schedule = components[5];
	          

	            // CONTROL ACTIVITY - Controlamos que el String Activity cumpla unos requisitos.
	            //****************************************************************************************************
	            if (!isValidActivity(activity)) {
	                System.out.println("WARNING: Invalid activity name, must be CLOSED, CERRADO, TANCAT AND MEETING, REUNIO, REUNION: " + activity);
	                registrar(fileIncidents, "WARNING: Invalid activity - " + line);
	                peticionesIncorrectas.add(line);
	                continue; // Pasar a la siguiente línea
	            }
	            // CONTROL SPACE
	            //****************************************************************************************************
	            if (!isValidSpace(space)) {
	                System.out.println("WARNING: Invalid space name must be SALA or SPACE: " + space);
	                registrar(fileIncidents, "WARNING: Invalid space must be SALA or SPACE - " + line);
	                peticionesIncorrectas.add(line);
	                continue; // Pasar a la siguiente línea
	            }
	            	                        
	            String registroLine = activity + " " + space + " " + dateIN + " " + dateOUT +" " + daysAtWeek + " " + schedule;
	            
	            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	            LocalDate dateIn;
	            LocalDate dateOut;
	            try {
	                dateIn = LocalDate.parse(dateIN, dateFormatter);
	                dateOut = LocalDate.parse(dateOUT, dateFormatter);
	            } catch (DateTimeParseException e) {
	                System.out.println("WARNING: Invalid date format: " + dateIN + " or " + dateOUT);
	                registrar(fileIncidents, "ERROR: Invalid date format - " + line);
	                peticionesIncorrectas.add(line);
	                continue; // Pasar a la siguiente línea
	            }
	            // CONTROL DATEIN DATEOUT
	            //****************************************************************************************************
	            if (!isValidDateRange(dateIn, dateOut)) {
	                System.out.println("ERROR: Invalid date range.");
	                registrar(fileIncidents, "WARNING: Invalid date range - " + line);
	                peticionesIncorrectas.add(line);
	                continue; // Pasar a la siguiente línea
	            }
	            // CONTROL DAYSATWEEK
	            //****************************************************************************************************                
	            LecturaConfig.leerVariablesConfig();
	            if (!isValidDaysAtWeek(daysAtWeek,LecturaConfig.getInLang())) {
	                System.out.println(LecturaConfig.getInLang());
	                System.out.println("WARNING: Days of week are not correct");
	                registrar(fileIncidents, "WARNING: Invalid Days at Week, please check them " + line);
	                peticionesIncorrectas.add(line);
	                continue; // Pasar a la siguiente línea
	            }
	            // CONTROL SCHEDULE
	            //****************************************************************************************************
	            if (!isValidSchedule(schedule)) {
	                System.out.println("WARNING: Invalid schedule format: " + schedule);
	                registrar(fileIncidents, "WARNING: Invalid schedule format - " + line);
	                peticionesIncorrectas.add(line);
	                continue; // Pasar a la siguiente línea
	            }
	            
	            peticionesCorrectas.add(registroLine);
	        }
	        scanner.close();
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    }
	    // Separamos en los ficheros las peticiones correctas en registo.log y las incorrectas en incidencias.log
	    escribirPeticionesEnArchivo(peticionesCorrectas, fileLog);
	    escribirPeticionesEnArchivo(peticionesIncorrectas, fileIncidents);
	    
	    if (peticionesCorrectas.isEmpty() && peticionesIncorrectas.isEmpty()) {
	        registrar(fileIncidents,"WARNING: There are not valid requests in the file or it is empty, please check it");
	    }
	    
	    return peticionesCorrectas;
	}

/************************************** METODOS ****************************************/	
	private static void registrar(String fileIncidents, String message) {
        LocalDateTime currentTime = LocalDateTime.now();
        String formattedDateTime = currentTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        String logMessage = "[" + formattedDateTime + "] " + message;

        try (FileWriter writer = new FileWriter(fileIncidents, true)) {
            writer.write(logMessage + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /* Se controla que el nombre de activity sea: close, cerrado, tancat / reunio, reunion, meeting*/
    private static boolean isValidActivity(String activity) {
        String lowerCaseActivity = activity.toLowerCase();
        return lowerCaseActivity.startsWith("reunio") || lowerCaseActivity.startsWith("meeting") ||
        		lowerCaseActivity.startsWith("tancat") || lowerCaseActivity.startsWith("closed") ||
        		lowerCaseActivity.startsWith("cerrado");
    }
    //Controlamos si space cumple: Que sea sala o space (sin importar mayusculas y minusculas)
    // y que no supero las 10 salas. 
    private static boolean isValidSpace(String space) {
        String spaceNumber = extractSpaceNumber(space);
        if (spaceNumber == null) {
            return false; // No se pudo extraer el número de sala o space
        }
        int number = Integer.parseInt(spaceNumber);
        return number >= 1 && number <= 10;
    }
    /* Metodo que nos permite extraer el numero despues de sala o space y nos controla que no sea mayor de 5. */
   	private static String extractSpaceNumber(String space) {
	        String lowercaseSpace = space.toLowerCase();
	        if (lowercaseSpace.startsWith("sala")) {
	            String numberPart = lowercaseSpace.substring(4);
	            if (numberPart.matches("\\d{1,5}")) {
	                return numberPart;
	            }
	        } else if (lowercaseSpace.startsWith("space")) {
	            String numberPart = lowercaseSpace.substring(5);
	            if (numberPart.matches("\\d{1,5}")) {
	                return numberPart;
	            }
	        }
	        	return null; // No se pudo extraer el número de sala o space
	    	}
   	private static boolean isValidDateRange(LocalDate dateIn, LocalDate dateOut) {
   		    LocalDate currentLimit = LocalDate.now().plusYears(1).withMonth(12).withDayOfMonth(31);
   		    LocalDate currentDate = LocalDate.now();
   		    if (dateIn.isAfter(currentLimit)|| dateOut.isAfter(currentLimit)) {
   		        System.out.println("ERROR: Date exceeds maximum limit");
   		        return false;
   		    }
   		    if (dateIn.isEqual(dateOut) || dateIn.isAfter(dateOut)) {
   		        System.out.println("ERROR: Invalid date range");
   		        return false;
   		    }
   		    if (dateIn.isBefore(currentDate) || dateOut.isBefore(currentDate)) {
   		        System.out.println("ERROR: Date is before the current date");
   		        return false;
   		    }
	   		 if (!dateIn.isBefore(dateOut)) {
	   	        System.out.println("ERROR: Invalid date range. dateIn must be before dateOut.");
	   	        return false;
	   	    }
	   		return true;
   		}
   	private static void escribirPeticionesEnArchivo(ArrayList<String> peticiones, String archivo) {
   	    try (FileWriter writer = new FileWriter(archivo, true)) {
   	        for (String peticion : peticiones) {
   	            LocalDateTime currentTime = LocalDateTime.now();
   	            String formattedDateTime = currentTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
   	            String logMessage = "[" + formattedDateTime + "] " + peticion;
   	            writer.write(logMessage + "\n");
   	        }
   	    } catch (IOException e) {
   	        e.printStackTrace();
   	    }
   	}

   	
   
   	private static boolean isValidDaysAtWeek(String daysAtWeek, String idioma) {
   	    String codigosDiasSemana = "";

   	    if (idioma.equals("CAT") || idioma.equals("ESP")) {
   	        String codigosCorrectos = "LMCJVSG";
   	        int prevIndex = -1;

   	        for (char c : daysAtWeek.toCharArray()) {
   	            int currentIndex = codigosCorrectos.indexOf(c);

   	            if (currentIndex == -1) {
   	                return false; // Carácter inválido
   	            }

   	            if (currentIndex <= prevIndex) {
   	                return false; // Carácter fuera de orden
   	            }

   	            if (codigosDiasSemana.contains(String.valueOf(c)) || c == ' ') {
   	                return false; // Carácter repetido o espacio en blanco
   	            }

   	            codigosDiasSemana += c;
   	            prevIndex = currentIndex;
   	        }
   	    } else if (idioma.equals("ENG")) {
   	        String codigosCorrectos = "MTWHFSN";
   	        int prevIndex = -1;

   	        for (char c : daysAtWeek.toCharArray()) {
   	            int currentIndex = codigosCorrectos.indexOf(c);

   	            if (currentIndex == -1) {
   	                return false; // Carácter inválido
   	            }

   	            if (currentIndex <= prevIndex) {
   	                return false; // Carácter fuera de orden
   	            }

   	            if (codigosDiasSemana.contains(String.valueOf(c))) {
   	                return false; // Carácter repetido
   	            }

   	            codigosDiasSemana += c;
   	            prevIndex = currentIndex;
   	        }
   	    } else {
   	        return false; // Idioma inválido
   	    }

   	    return true; // días de la semana válidos
   	}
   	
   	private static boolean isValidSchedule(String schedule) {
   	    String[] timeRanges = schedule.split("_");
   	    int previousEndHour = -1;

   	    for (String range : timeRanges) {
   	        String[] times = range.split("-");

   	        if (times.length != 2) {
   	            return false; // Formato incorrecto
   	        }

   	        String startHourStr = times[0];
   	        String endHourStr = times[1];

   	        if (!startHourStr.matches("\\d+") || !endHourStr.matches("\\d+")) {
   	            return false; // Contiene caracteres no numéricos
   	        }

   	        int startHour = Integer.parseInt(startHourStr);
   	        int endHour = Integer.parseInt(endHourStr);

   	        if (startHour >= 24 || endHour > 24) {
   	            return false; // Hora de inicio o fin supera las 24 horas
   	        }

   	        if (startHour >= endHour) {
   	            return false; // Hora de inicio no es menor que la hora de fin
   	        }

   	        if (previousEndHour != -1 && startHour <= previousEndHour) {
   	            return false; // Hora de inicio no es mayor que la hora de fin del tramo anterior
   	        }

   	        previousEndHour = endHour;
   	    }

   	    return true;
   	}

}