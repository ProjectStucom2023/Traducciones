package g_agenda;

import java.io.FileWriter;
import java.io.IOException;

public class generarPoliticaHTML {
    public static void PoliticaHTML() {
        String politicaFileName = "politica.html";
        try {
            FileWriter fileWriter = new FileWriter(politicaFileName);
            fileWriter.write("<html>\n");
            fileWriter.write("<head>\n");
            fileWriter.write("<title>Política del programa</title>\n");
            fileWriter.write("<style>\n");
            fileWriter.write("body { background-color: #f0f0f0; }\n");
            fileWriter.write("h1 { color: #000000; font-size: 24px; }\n");
            fileWriter.write("p { color: #000000; font-size: 18px; }\n");
            fileWriter.write("</style>\n");
            fileWriter.write("</head>\n");
            fileWriter.write("<body>\n");
            fileWriter.write("<h1>Política del programa</h1>\n");
            fileWriter.write("<h2>Català</h2>\n");
            fileWriter.write("<p>Aquest programa gestiona les reserves de les sales per a reunions i altres esdeveniments. " +
                    "Els usuaris poden fer peticions per a reservar un espai i un horari determinat. El sistema processa " +
                    "les peticions i genera un calendari amb les reserves aprovades. Si alguna petició no pot ser " +
                    "realitzada, es registra un missatge d'error.</p>\n");
            fileWriter.write("<h2>Español</h2>\n");
            fileWriter.write("<p>Este programa gestiona las reservas de las salas para reuniones y otros eventos. " +
                    "Los usuarios pueden realizar peticiones para reservar un espacio y un horario determinado. " +
                    "El sistema procesa las peticiones y genera un calendario con las reservas aprobadas. " +
                    "Si alguna petición no puede ser realizada, se registra un mensaje de error.</p>\n");
            fileWriter.write("<h2>English</h2>\n");
            fileWriter.write("<p>This program manages room reservations for meetings and other events. Users can make " +
                    "requests to reserve a specific space and schedule. The system processes the requests and generates " +
                    "a calendar with the approved reservations. If a request cannot be fulfilled, an error message is logged.</p>\n");
            fileWriter.write("</body>\n");
            fileWriter.write("</html>\n");
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}