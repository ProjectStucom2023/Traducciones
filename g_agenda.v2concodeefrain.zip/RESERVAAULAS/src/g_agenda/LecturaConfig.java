package g_agenda;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Scanner;

public class LecturaConfig {
// Inicializamos las cuatro parametros de Config.txt
	private static String year = null;
	private static String month = null;
	private static String inLang = null;
	private static String outLang = null;
	
// Creamos un metodo para extraer las variables de config.txt para luego poder llamarlas desde otra clase.
			public static void leerVariablesConfig() {
			    String fileConfig = "config.txt";
			    try {
			        File file = new File(fileConfig);
			        Scanner scanner = new Scanner(file);

			        // Leer la primera línea
			        String firstLine = scanner.nextLine();
			        String[] valuesFirstLine = firstLine.split(" ");
			        year = valuesFirstLine[0];
			        month = valuesFirstLine[1];

			        // Leer la segunda línea
			        String secondLine = scanner.nextLine();
			        String[] valuesSecondLine = secondLine.split(" ");
			        inLang = valuesSecondLine[0];
			        outLang = valuesSecondLine[1];

			        scanner.close();
			    } catch (Exception e) {
			        e.printStackTrace();
			    }
			}
// Generamos los getters para las llamadas de variables.
			public static String getYear() {return year;}
			public static String getMonth() {return month;}
			public static String getInLang() {return inLang;}
			public static String getOutLang() {return outLang;}
		
// Con ese metodo booleano retornamos true si todo el config.txt es correcto sino enviamos un false al que le damos un mensaje
// dentro de incidencias.
			public static boolean leerConfig() {
	        String fileConfig = "config.txt";
	        String fileIncidents = "incidencies.log";
	        String fileLog = "registro.log";
	        try {
	        	// Control 1 : Si fichero esta vacio
	            File file = new File(fileConfig);
	            if (file.length() == 0) {
	                String errorMessage = "WARNING: The file is empty";
	                registrar(fileIncidents, errorMessage);
	                return false; 
	            }
	            // Control 2 : Si no hay primera linea.
	            Scanner scanner = new Scanner(file);
	            if (!scanner.hasNextLine()) {
	                String errorMessage = "WARNING: Invalid file format. Missing first line";
	                registrar(fileIncidents, errorMessage);
	                scanner.close();
	                return false; 
	            }
	            // Control 3 : Formato de dos valores incorrecto.
	            String firstLine = scanner.nextLine();
	            String[] valuesFirstLine = firstLine.split(" ");
	            if (valuesFirstLine.length != 2) {
	                String errorMessage = "WARNING: Invalid file format. Incorrect number of values in the first line";
	                registrar(fileIncidents, errorMessage);
	                scanner.close();
	                return false; 
	            }
	            // Control 4 : Si lo escrito en los dos campos son numeros enteros.
	            int year, month;
	            try {
	                year = Integer.parseInt(valuesFirstLine[0]);
	                month = Integer.parseInt(valuesFirstLine[1]);
	            } catch (NumberFormatException e) {
	                String errorMessage = "WARNING: Invalid file format. Invalid values in the first line";
	                registrar(fileIncidents, errorMessage);
	                scanner.close();
	                return false; 
	            }
	            /*Control 5  : Obtenemos la instancia actual del calendario utilizando Calendar.getInstance(). con la que conseguimos año y mes actual.
	             * Seguidamene se comprueba que el año introducido sea mayor al actual y que el mes sea entre 1 y 12. Si hay error se 
	             * registra en incidencies.log y se devuelve un false.*/
	            Calendar calendar = Calendar.getInstance();
	            int currentYear = calendar.get(Calendar.YEAR);
	            int currentMonth = calendar.get(Calendar.MONTH) + 1;
	            if (year < currentYear || (year == currentYear && month < currentMonth) || month < 1 || month > 12) {
	                String errorMessage = "WARNING: Year and month must be greater than the current date and valid (1-12)";
	                registrar(fileIncidents, errorMessage);
	                scanner.close();
	                return false; 
	            }
	            /* Control 6 : Usando (Calendar.YEAR,1) añadimos un año a la fecha actual. Seguidamente obtenemos con dos variables el año y mes permitido
	             * (sumanos 1 ya que Calendar.MONTH va del 0 al 11) y los comparamos con las variables year y month escritas en el fichero
	             * Config.txt y verificamos que no sean superiores a la fecha actual mes un año.*/
	            calendar.add(Calendar.YEAR, 1);
	            calendar.set(Calendar.MONTH, Calendar.DECEMBER);
	            calendar.set(Calendar.DAY_OF_MONTH, 31);

	            int maxYearAllowed = calendar.get(Calendar.YEAR);
	            int maxMonthAllowed = calendar.get(Calendar.MONTH) + 1;

	            if (year > maxYearAllowed || (year == maxYearAllowed && month > maxMonthAllowed)) {
	                String errorMessage = "WARNING: Year and month cannot exceed " + maxYearAllowed + "/" + maxMonthAllowed;
	                registrar(fileIncidents, errorMessage);
	                scanner.close();
	                return false;
	            }
	            /* Control 7 : Realizamos una comprobacion unica en la que si la fecha actual y la fecha del fichero Config.txt son iguales, nos de un 
	             * mensaje de error especifico.*/
	            if (year == currentYear && month == currentMonth) {
	                String errorMessage = "WARNING: Reservations cannot be made in the current month. Please choose a future month.";
	                registrar(fileIncidents, errorMessage);
	                scanner.close();
	                return false; 
	            }
	            /*Control 8 : Comprobamos que la segunda linea tenga informacion */ 
	            if (!scanner.hasNextLine()) {
	                String errorMessage = "WARNING: Invalid file format. Missing second line";
	                registrar(fileIncidents, errorMessage);
	                scanner.close();
	                return false; 
	            }
	            /*Control 9 : Al igual como hemos hecho en la primera linea verificamos que contenga 2 string separados por un espacio.Si no es correcto
	             * nos da un error dentro de incidencies.log */
	            String secondLine = scanner.nextLine();
	            String[] valuesSecondLine = secondLine.split(" ");
	            if (valuesSecondLine.length != 2) {
	                String errorMessage = "WARNING: Invalid file format. Incorrect number of values in the second line";
	                registrar(fileIncidents, errorMessage);
	                scanner.close();
	                return false; // Error de formato, devuelve false
	            }
	            /* Control 10 :  En este caso introducciomos los valores del primer y segundo string como idioma de entrada y idioma de salida verificando 
	             * que sean solo CAT, ENG,ESP */
	            String inLang = valuesSecondLine[0];
	            String outLang = valuesSecondLine[1];
	            if (!(inLang.equals("CAT") || inLang.equals("ESP") || inLang.equals("ENG")) ||
	                    !(outLang.equals("CAT") || outLang.equals("ESP") || outLang.equals("ENG"))) {
	                String errorMessage = "WARNING: Invalid file format. Only CAT, ESP and ENG are supported";
	                registrar(fileIncidents, errorMessage);
	                scanner.close();
	                return false; 
	            }
	            // Se Crea un writer del fichero de registro.log (fileLog) para poder escribir en cada linia, la fecha y hora actual, para control de errores.
	            // Siempre y cuando haya pasado todo el codigo anterior sin errores.
	            FileWriter writer = new FileWriter(fileLog);
	            LocalDateTime currentTime = LocalDateTime.now();
	            String formattedDateTime = currentTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
	            String logMessage = "[" + formattedDateTime + "]";
	            writer.write(logMessage + "CONFIG.TXT PARAMETERS - YEAR:" + year + " MONTH:"+ 
	            month+ " IDIOMS IN:"+inLang+" OUT:"+outLang+"\n");
	            writer.close();
	            scanner.close();
	            return true; // Proceso de lectura y verificación exitoso, devuelve true
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	            return false; // Error al leer el archivo, devuelve false
	        } catch (IOException e) {
	            e.printStackTrace();
	            return false; // Error al escribir en el archivo de salida, devuelve false
	        }
	    }
// Metodo para registrar errores dentro del fichero de incidencias.
		static void registrar(String file, String message) {
	        try {
	            FileWriter writer = new FileWriter(file, true);
	            LocalDateTime currentTime = LocalDateTime.now();
	            String formattedDateTime = currentTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
	            String logMessage = "[" + formattedDateTime + "]";
	            writer.write(logMessage + message + "\n");
	            writer.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
}