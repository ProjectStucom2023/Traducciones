package g_agenda;

import java.io.File;
import java.io.PrintWriter;
import java.awt.Desktop;

public class generadorPortada {

	public static void createHtmlFile() {
	    String imagePath = "LogoEmpresaNF.png";
	    String[] pages = {"sala1.html", "sala2.html", "sala3.html", "sala4.html", "sala5.html"};
	    String[] spacePages = {"space1.html", "space2.html", "space3.html", "space4.html", "space5.html"};
	    String[] cities = {"Tokyo", "Paris", "Sidney", "Pekin", "Dubai"};
	    String[] rooms = {"(Sala/Space) 1", "(Sala/Space) 2", "(Sala/Space) 3", "(Sala/Space) 4", "(Sala/Space) 5"};

	    try {
            // Crea el archivo no-requests.html
            PrintWriter noRequestsWriter = new PrintWriter(new File("no-requests.html"));
            noRequestsWriter.println("<!DOCTYPE html>");
            noRequestsWriter.println("<html>");
            noRequestsWriter.println("<head>");
            noRequestsWriter.println("<title>No request</title>");
            noRequestsWriter.println("<style>");
            noRequestsWriter.println("body { display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }");
            noRequestsWriter.println(".container { text-align: center; }");
            noRequestsWriter.println(".button { display: inline-block; padding: 10px 20px; background-color: #007BFF; color: white; text-decoration: none; border-radius: 5px; }");
            noRequestsWriter.println("</style>");
            noRequestsWriter.println("</head>");
            noRequestsWriter.println("<body>");
            noRequestsWriter.println("<div class=\"container\">");
            noRequestsWriter.println("<h2>No request in this space</h2>");
            noRequestsWriter.println("<p><small>Sense peticions en aquesta sala</small><br/>");
            noRequestsWriter.println("<small>Sin peticiones en esta sala</small></p>");
            noRequestsWriter.println("<a href=\"index.html\" class=\"button\">Back to main page</a>");
            noRequestsWriter.println("</div>");
            noRequestsWriter.println("</body>");
            noRequestsWriter.println("</html>");
            noRequestsWriter.close();

            // Crea el archivo index.html
            PrintWriter writer = new PrintWriter(new File("index.html"));
            
            writer.println("<head>");
            writer.println("<title>G_Agenda</title>");
            writer.println("<style>");
            writer.println("body { display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; font-family: Arial, sans-serif; background-image: url('fondo.jpg'); background-size: cover; background-repeat: no-repeat; background-position: center; }");
            writer.println(".date-time { position: absolute; top: 10px; left: 10px; color: #000033; font-weight: bold; font-size: 12px; font-family: Arial; }"); // posiciona el tiempo y fecha en la esquina izquierda
            writer.println("</style>");
            writer.println("<script>");
            writer.println("window.onload = function() {");
            writer.println("    var dateElement = document.getElementById('date-time');");
            writer.println("    function updateDateTime() {");
            writer.println("        var now = new Date();");
            writer.println("        var date = now.toLocaleDateString();");
            writer.println("        var time = now.toLocaleTimeString();");
            writer.println("        dateElement.innerHTML = date + ' ' + time;");
            writer.println("    }");
            writer.println("    updateDateTime();");
            writer.println("    setInterval(updateDateTime, 1000);"); // actualiza la hora y fecha cada segundo
            writer.println("};");
            writer.println("</script>");
            writer.println("</head>");
            writer.println("<body>");
            writer.println("<div id=\"date-time\" class=\"date-time\"></div>"); // coloca la fecha y hora aquí
           
            writer.println("</body>");
            writer.println("</html>");

            writer.println("<!DOCTYPE html>");
            writer.println("<html>");
            writer.println("<head>");
            writer.println("<title>G_Agenda</title>");
            writer.println("<style>");
            writer.println("body { display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; font-family: Arial, sans-serif; background-image: url('fondo.jpg'); background-size: cover; background-repeat: no-repeat; background-position: center; }");
           // writer.println("body { display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; font-family: Arial, sans-serif; background-color: #000033; }");
            writer.println(".row { display: flex; justify-content: center; margin: 20px 0; }"); 
            writer.println(".city-container { width: 150px; height: 48px; padding: 5px; border-radius: 10px; background-color: #000033; color: white; text-align: center; margin: 0 10px; }");


            writer.println(".city { font-size: 18px; font-weight: bold; margin-bottom: 5px; }");
            writer.println(".room { font-size: 14px; }");
            writer.println(".available-rooms { color: #000080; font-size: 24px; font-weight: bold; text-align: center; font-family: Arial, sans-serif; }");  // Azul marino (#000080)
            writer.println("p, h2 { margin: 0 10px; }"); 
            writer.println("a, h2 { font-size: 18px; font-weight: bold; text-decoration: none; }");
            writer.println("hr { border: none; border-top: 2px solid #000080; width: 50%; margin: 20px auto; }");  // Azul marino (#000080)
            writer.println("</style>");
            writer.println("</head>");
            writer.println("<body>");
            writer.println("<img src=\"" + imagePath + "\" alt=\"G_agenda\" style=\"width:466px; height:287px;\">");
            writer.println("<h2 class=\"available-rooms\" style=\"color: #000033; font-weight: bold; font-size: 30px; font-family: Arial;\">Available Rooms</h2>");
            writer.println("<h2 class=\"available-rooms\" style=\"color: #000033; font-weight: bold; font-size: 15px; font-family: Arial;\">Sales disponibles / Salas disponibles</h2>");

            writer.println("<hr style=\"border-top: 5px solid #000033; width: 29%;\">");

            
            writer.println("<div class=\"row\">");
            for (int i = 0; i < 3; i++) {
                String page = new File(pages[i]).exists() ? pages[i] 
                             : new File(spacePages[i]).exists() ? spacePages[i] 
                             : "no-requests.html";
                writer.println("<div class=\"city-container\">");
                writer.println("<p class=\"city\" style=\"font-size: 24px; font-weight: bold;\"><a href=\"" + page + "\" style=\"text-decoration: none; color: white;\">" + cities[i] + "</a></p>");
                writer.println("<p class=\"room\">" + rooms[i] + "</p>");
                writer.println("</div>");
            }
            writer.println("</div>");
            writer.println("<div class=\"row\">");
            for (int i = 3; i < pages.length; i++) {
                String page = new File(pages[i]).exists() ? pages[i] 
                             : new File(spacePages[i]).exists() ? spacePages[i] 
                             : "no-requests.html";
                writer.println("<div class=\"city-container\">");
                writer.println("<p class=\"city\" style=\"font-size: 24px; font-weight: bold;\"><a href=\"" + page + "\" style=\"text-decoration: none; color: white;\">" + cities[i] + "</a></p>");
                writer.println("<p class=\"room\">" + rooms[i] + "</p>");
                writer.println("</div>");
            }
            
            writer.println("</div>");
            writer.println("</body>");
            writer.println("</html>");
            writer.close();

            // Intenta abrir el archivo index.html en el navegador
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE))
		            {
		                Desktop.getDesktop().browse(new File("index.html").toURI());
		            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}